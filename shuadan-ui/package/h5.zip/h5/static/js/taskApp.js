// 版本一
// import taskApp1 from '../img/task-app-1.png'
// import taskApp2 from '../img/task-app-2.png'
// import taskApp3 from '../img/task-app-3.png'
// import taskApp4 from '../img/task-app-4.png'
// import taskApp5 from '../img/task-app-5.png'
// import taskApp6 from '../img/task-app-6.png'

// 版本二
import taskApp1 from '../img/task-app-single-1.png'
import taskApp2 from '../img/task-app-single-2.png'
import taskApp3 from '../img/task-app-single-3.png'
import taskApp4 from '../img/task-app-single-4.png'
import taskApp5 from '../img/task-app-single-5.png'
import taskApp6 from '../img/task-app-single-6.png'
import taskApp7 from '../img/task-app-single-7.png'
import taskApp8 from '../img/task-app-single-8.png'
import taskApp9 from '../img/task-app-single-9.png'
import taskApp10 from '../img/task-app-single-10.png'
import taskApp11 from '../img/task-app-single-11.png'
import taskApp12 from '../img/task-app-single-12.png'

const taskAppList = [{
    url: taskApp1
  },
  {
    url: taskApp2
  },
  {
    url: taskApp3
  },
  {
    url: taskApp4
  },
  {
    url: taskApp5
  },
  {
    url: taskApp6
  },
  {
    url: taskApp7
  },
  {
    url: taskApp8
  },
  {
    url: taskApp9
  },
  {
    url: taskApp10
  },
  {
    url: taskApp11
  },
  {
    url: taskApp12
  },
]

export default taskAppList