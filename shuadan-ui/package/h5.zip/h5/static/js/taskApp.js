import taskApp1 from '../img/task-app-1.png'
import taskApp2 from '../img/task-app-2.png'
import taskApp3 from '../img/task-app-3.png'
import taskApp4 from '../img/task-app-4.png'
import taskApp5 from '../img/task-app-5.png'
import taskApp6 from '../img/task-app-6.png'

const taskAppList = [{
    url: taskApp1
  },
  {
    url: taskApp2
  },
  {
    url: taskApp3
  },
  {
    url: taskApp4
  },
  {
    url: taskApp5
  },
  {
    url: taskApp6
  },
]

export default taskAppList